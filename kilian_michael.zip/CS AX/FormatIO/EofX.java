/*
 *	EofX.java
 *	==============
 *      Copyright (C) 1999, Ron Poet, Dept. Comp.Sci. Uni Glasgow Scotland
 *	$Author: ron $
 *	$Date: 1999/08/30 16:36:05 $
 *	$Revision: 1.2 $
 *
 *	End Of File Exception.
 */

package	FormatIO;

/*====================================*/
public	class	EofX extends Exception
/*====================================*/
	{
public	EofX()	{ super("End of File"); }
	}
